import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Ui class for the inventory
 */
public class InventoryUi extends World
{
    public Farm farmWorld;
    // mengatur dasar pemposisian item
    int baseYImg = 100;
    int baseYName = 120;
    int baseYPrice = 140;
    int baseX = 120;
    // mengatur jarak antar slot inventory
    int shift = 80;
    // memodifikasi inventori untuk menambahkan lebih banyak shift untuk setiap kolom
    int iMod = 0;

    Item item;
    Text textName;
    Text textPrice;

    public InventoryUi(Farm world){    
        // membuat dunia baru dengan ukuran 1024x512 dengan ukuran sel 1x1 piksel.
        super(1024, 512, 1);

    
        this.farmWorld = world;
        prepare();
    }

    private void prepare()
    {
        // menambahkan tombol keluar untuk kembali ke world sebelumnya
        addObject(new ExitButton(this.farmWorld),1008,16);

        // menambahkan objek untuk menampilkan uang
        addObject(new MoneyIcon(),750,120);
        addObject(new MoneyText(),850,120);

        // menambahkan objek untuk bagian pemillihan bibit
        Text seedSelectText = new Text("", 30);
        addObject(seedSelectText, 850, 200);
        addObject(new SeedSelectButton(seedSelectText), 750, 200);

        // menambahkan item dari data save-an ke inventory
        Data data = new Data();
        for (int i = 0; i < data.items.length; i++) {
            if (i == 0){
                this.item = new Radish();
            }
            else if(i == 1){
                this.item = new Carrot();
            }
            else if(i == 2){
                this.item = new RadishSeed();
            }
            else if(i == 3){
                this.item = new CarrotSeed();
            }
            // menggunakan Placeholder jika tidak ada item yang ditetapkan ke slot inventaris
            else {
                this.item = new Placeholder();
            }
            // Menyesuaikan nilai dasar/posisi pada sumbu y dari item saat pindah baris (ketika mencapai ID 8 atau 16
            if (i % 8 == 0 && i != 0) {
                this.baseYImg += shift;
                this.baseYName += shift;
                this.baseYPrice += shift;
                // "reset" shift on new row
                this.iMod += 8;
            }

            // Membuat objek teks dengan data dari file save-an.
            this.textName = new Text(this.item.getName()+": "+data.items[i], 15);
            this.textPrice = new Text("Worth: "+this.item.getSellPrice(), 15);

            //Menggeser sumbu x.
            int xAdd = (i-this.iMod)*this.shift;

            addObject(this.item, this.baseX+xAdd, this.baseYImg);
            addObject(this.textName, this.baseX+xAdd, this.baseYName);
            addObject(this.textPrice, this.baseX+xAdd, this.baseYPrice);
        }
    }
}
