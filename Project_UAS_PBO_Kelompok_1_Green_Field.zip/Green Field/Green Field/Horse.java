import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Horse extends Animal
{
    // Menambahkan suara untuk makan wortel
    private GreenfootSound carrotSound = new GreenfootSound("sound1.mp3");

    // Menambahkan suara untuk makan lobak
    private GreenfootSound radishSound = new GreenfootSound("sound2.mp3");

    public void act()
    {
        if(Greenfoot.mouseClicked(this)) {
            // memberikan makan ke kuda
            this.feedHorse();
        }
    }

    // coding yang di eksekusi saat memberi makan kuda
    private void feedHorse(){
        Data data = new Data();
        if (data.items[1] > 0){
            // hilangkan 1 wortel saat memberi makan kuda
            data.items[1] -= 1;
            data.write();

            Carrot carrot = new Carrot();
            getWorld().addObject(carrot, 25, 2);
            
            Greenfoot.delay(80);
            getWorld().removeObject(carrot);
            
            // animasi saat kuda dikasilh makan
            this.turn(20);
            Greenfoot.delay(20);
            this.turn(-20);

            // Memutarkan suara wortel
            carrotSound.play();
        }
        else if (data.items[2] > 0) {
            // hilangkan 1 lobak saat memberi makan kuda
            data.items[2] -= 1;
            data.write();

            Radish radish = new Radish();
            getWorld().addObject(radish, 25, 2);
            
            Greenfoot.delay(80);
            getWorld().removeObject(radish);
            
            // animasi saat memberi makan kuda
            this.turn(20);
            Greenfoot.delay(20);
            this.turn(-20);

            // Memutarkan suara lobak
            radishSound.play();
        }
    }
}
