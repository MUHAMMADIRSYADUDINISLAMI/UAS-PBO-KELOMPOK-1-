import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class ExitButton extends Interface
{
    World exitTo;
    public ExitButton(World world) {
        this.exitTo = world;
    }

    public void act()
    {
        if(Greenfoot.mouseClicked(this) || Greenfoot.isKeyDown("escape")) {
            // keluar dari world konstruktor saat berada di toko inventory atau help.
            if (getWorld() instanceof InventoryUi || getWorld() instanceof ShopUi || getWorld() instanceof Help) {
                Greenfoot.setWorld(exitTo);
            }
        }
    }
}
