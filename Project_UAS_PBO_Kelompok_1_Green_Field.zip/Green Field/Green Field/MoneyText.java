import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class MoneyText extends Interface
{
    public void act()
    {
        // Mengambil uang dari save dan menampilkannya
        Data data = new Data();
        setImage(new GreenfootImage("" + data.getMoney(), 40, Color.WHITE, new Color(0,0,0,0)));

        if(Greenfoot.mouseClicked(this)) {
            data.addMoney(100);
        }
    }
}
