import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Button used for changing the currently selected seed for planting.
 */
public class SeedSelectButton extends Interface
{
    Data data = new Data();

    Text seedSelectText;
    boolean[] seeds = {true, false};
    // 0 - lobak
    // 1 - wortel

    int selected = 0;

    public SeedSelectButton(Text text) {
        this.seedSelectText = text;
        
        // Dapatkan biji yang saat ini dipilih dari save ketika bukan pada save baru
        if(this.data.getSeedSelected() != -1){
            for (int i = 0; i < this.seeds.length; i++) {
                if (i==this.data.getSeedSelected()) {
                    this.seeds[i] = true;
                    this.selected = i;
                } else{
                    this.seeds[i] = false;
                }
            }
            this.updateText();
        } else{
            // 
            this.data.setSeedSelected(0);
            this.selected = 0;
        }
    }

    public void act()
    {
        if(Greenfoot.mouseClicked(this)){
            // Mendapatkan biji yang dipilih dan mengatur semua nilai menjadi salah
            for (int i = 0; i < this.seeds.length; i++) {
                if(this.seeds[i] == true) {
                    selected = i;
                    this.seeds[i] = false;
                    break;
                }
            }
            
            // Mengatur biji berikutnya atau pertama (jika berada di akhir) yang tersedia menjadi yang dipilih
            try {
                this.selected += 1;
                this.seeds[selected] = true;
            }
            catch(ArrayIndexOutOfBoundsException e) {
                this.seeds[0] = true;
                this.selected = 0;
            }

        }
        
        this.updateText();
        this.data.setSeedSelected(selected);
    }

    private void updateText() {
        if(this.seeds[0]) {
            this.seedSelectText.setText("Radish");
        }
        else if(this.seeds[1]) {
            this.seedSelectText.setText("Carrot");
        }
    }
}
