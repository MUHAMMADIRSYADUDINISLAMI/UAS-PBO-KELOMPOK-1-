import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.File;  // mengimpor file kelas
import java.io.FileWriter;
import java.io.IOException;

import java.io.FileNotFoundException;  // mengimport kelas ini untuk menghandle error
import java.util.Scanner;

/**
 * Data class holds some game data.
 */
public class Data extends Actor
{
    String filename = "save.txt";

    public static int[] items = new int[24];
    // id inventory/item 
    // 0 - lobak
    // 1 - wortel
    // 2 - bibit lobak
    // 3 - bibit wortel

    // uang, pemilihan bibit
    private static int[] data = {0,-1};

    // membuat save file apabila tidak ada data save yang di load atau di read
    public Data(){
        try {
            File file = new File(this.filename);
            //membaca file apabila ada
            if (!file.createNewFile()) {
                this.read();
            }
        } catch(IOException e){}
        this.write();
    }

    //menulis data file, dengan nilai return true apa bila berhasil
    public boolean write(){
        try {
            FileWriter writer = new FileWriter(this.filename);
            writer.write(Integer.toString(this.data[0]) + "\n");
            writer.write(Integer.toString(this.data[1]) + "\n");
            writer.write(this.arrayToString(items));
            writer.close();
            return true;
        } catch (IOException e) {return false;}
    }

    //membaca data
    public void read(){
        try {
            File file = new File(this.filename);
            Scanner reader = new Scanner(file);
            int i = 0;
            while (i < 3) {
                String tempdata = reader.nextLine();
                if(i<2){
                    this.data[i] = Integer.parseInt(tempdata);
                }
                else if (i==2){
                    this.items = this.stringToArray(tempdata);
                }
                i += 1;
            }
            reader.close();
        } catch (FileNotFoundException e) {}
    }

    public int getMoney(){return this.data[0];}

    public void setMoney(int amount){
        this.data[0] = amount;
        this.write();
    }

    public void addMoney(int amount){
        this.data[0] += amount;
        this.write();
    }

    public int getSeedSelected(){return this.data[1];}

    public void setSeedSelected(int seed){
        this.data[1] = seed;
        this.write();
    }

    public void addItem(int id, int count) {
        this.items[id] += count;
        this.write();
    }

    private String arrayToString(int[] array){
        String string = "";
        // Mengulangi array dan mengembalikan string yang dipisahkan oleh koma
        for (int i = 0; i < array.length; i++) {
            string += Integer.toString(array[i])+",";
        }
        return string;
    }

    private int[] stringToArray(String string){
        // Memisahkan string berdasarkan koma (,), dan menaruh nilainya ke dalam stringArr.
        String[] stringArr = string.split(",");
        // Mengulangi array integer yang baru dan menyimpan string sebagai bilangan bulat dalam intArr.
        int[] intArr = new int[24];
        for (int i = 0; i < intArr.length; i++) {
            intArr[i] = Integer.parseInt(stringArr[i]);
        }
        return intArr;
    }
    float i = 0.5f;
}
