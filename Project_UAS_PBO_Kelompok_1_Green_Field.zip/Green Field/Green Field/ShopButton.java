import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Button to change world to Shop.
 */
public class ShopButton extends Interface
{
    public void act()
    {
        if(Greenfoot.mouseClicked(this)) {
            //mengubah world ke world shop dan menyediakan world saat ini sebagai argumen untuk dikembalikan nanti
            Greenfoot.setWorld(new ShopUi((Farm)this.getWorld()));
        }
    }
}
