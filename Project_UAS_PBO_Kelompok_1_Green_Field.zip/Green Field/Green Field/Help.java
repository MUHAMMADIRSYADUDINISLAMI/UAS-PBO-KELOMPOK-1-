import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Class to show help.
 */
public class Help extends World
{
    World farmWorld;
    //menambahkan kelas help untuk memberikan tutorial cara bermain
    public Help(Farm world)
    {    
        //membuat dunia baru dengan sel 32x16 dengan ukuran sel 32x32 piksel.

        super(32, 16, 32);

        //inisialisasi kelas "help" dengan nilai parameter world agar memungkinkan untuk kelas "help" objek world
        this.farmWorld = world;
        prepare();
    }

    private void prepare()
    {
        // menambahkan tombol exit untuk kembali ke world sebelumnya
        addObject(new ExitButton(this.farmWorld),1008,16);

        // menambahkan text pada kelas help yang akan ditampilkan sebagai tutorial
        addObject(new Text("Tampilan UI", 40), 16,0);
        addObject(new Text("Tas pada farm = Inventory", 20), 16,1);
        addObject(new Text("koin pada Farm = Shop", 20), 16,2);
        addObject(new Text("icon yang dapat di klik pada UI farm adalah Koin dan Tas", 20), 16,3);

        addObject(new Text("Bertani", 40), 16,4);
        addObject(new Text("klik kanan kiri mouse untuk menanam", 20), 16,5);
        addObject(new Text("klik kanan pada mouse untuk memetik", 20), 16,6);
        addObject(new Text("mengganti jenis bibit (klik kantong bibit)", 20), 16,7);
        addObject(new Text("anda bisa membeli bibit di shop dengan harga yang tertera", 20), 16,8);

        addObject(new Text("berbelanja", 40), 16,9);
        addObject(new Text("untuk membeli item di toko klik pada ikon yang ingin dibeli", 20), 16,10);

        addObject(new Text("menjual", 40), 16,11);
        addObject(new Text("untuk menjual klik item pada inventory", 20), 16,12);
    }
}
