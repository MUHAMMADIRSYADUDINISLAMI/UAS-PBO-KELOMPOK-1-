import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Main world of this project.
 */
public class Farm extends World
{
    // Membuat lahan untuk ditanami
    int[][] fields = {
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        };
    //koordinat awal penempatan lapangan (pojok kiri/atas)
    int[] fieldsStartPos = new int[]{2,2};

    public Farm()
    {    
        // membuat new world dengan sel 32x16 dengan ukuran sel 32x32 piksel.
        super(32, 16, 32);
        prepare();
        
        // memberikan player uang pada new save
        Data data = new Data();
        if(data.getMoney()<=0){
            data.setMoney(20);
        }
    }
    
    public void act(){
        // mengatur agar kecepatan tumbuh tumbuhan tidak dapat di atur player
        Greenfoot.setSpeed(50);
        
        if(Greenfoot.isKeyDown("f1")) {
            Greenfoot.setWorld(new Help(this));
        }
    }

    private void prepare()
    {
        //menambahkan objek kuda, invetory dan shop kedalam dunia
        addObject(new InventoryButton(),1,14);
        addObject(new ShopButton(),3,14);
        addObject(new Horse(),28,3);

        // menaruh lada pada dunia game
        for (int i = 0; i < this.fields.length; i++) {
            for (int j = 0; j < this.fields[i].length; j++) {
                if(this.fields[i][j] == 1) {
                    Field field = new Field();
                    addObject(field, this.fieldsStartPos[0]+j, this.fieldsStartPos[1]+i);
                }
            }
        }
    }
}
